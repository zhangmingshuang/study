Web Console
===

Arthas supports the Web Console. After attach success, the user can access: [http://127.0.0.1:8563/](http://127.0.0.1:8563/).

The user can fill in the IP and connect the remote arthas on other machines.

![web console](_static/web-console-local.png)


If you have suggestions for the Web Console, please leave a message here: [https://github.com/alibaba/arthas/issues/15](https://github.com/alibaba/arthas/issues/15)