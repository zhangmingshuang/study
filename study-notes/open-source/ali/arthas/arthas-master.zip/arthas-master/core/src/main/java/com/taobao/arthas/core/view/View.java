package com.taobao.arthas.core.view;

/**
 * 命令行控件<br/>
 * Created by vlinux on 15/5/7.
 */
public interface View {

    /**
     * 输出外观
     */
    String draw();

}